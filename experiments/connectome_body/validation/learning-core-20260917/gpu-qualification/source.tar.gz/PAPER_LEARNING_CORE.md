# Imitation and reinforcement learning core

The execution priority is the final section of [GOAL.md](../GOAL.md).
[learning_core.json](configs/paper/learning_core.json) now schedules only the five-seed BC→PPO cross-body core.
`learning_regimes.json` retains the deferred 120-cell training-regime comparison.
The linear-memory diagnostic remains planned but is excluded from this initial
embodied worker by `launch_regimes: ["bc_ppo"]`. The full
paper plans remain separate and must be recompiled after this source change.

```sh
uv run --no-sync python -m connectome_body.compatibility.learning_study plan --config configs/paper/learning_core.json --output runs/learning-core-v1
uv run --no-sync python -m connectome_body.compatibility.learning_study data --plan runs/learning-core-v1/plan.json
uv run --no-sync python scripts/qualify_learning_core.py --plan runs/learning-core-v1/plan.json --output runs/learning-core-qualification --max-seconds 1200
uv run --no-sync python -m connectome_body.compatibility.learning_study worker --plan runs/learning-core-v1/plan.json --qualification runs/learning-core-qualification/qualification.json --experiment cross_body_core --max-runs 1 --max-seconds 1800
uv run --no-sync python -m connectome_body.compatibility.learning_study report --plan runs/learning-core-v1/plan.json --output reports/learning-core-v1
```

Compile inside the machine executing training. Body paths and source hashes are
frozen. The worker requires a passing qualification for that exact plan. Time
limits pause at checkpoint boundaries; an external supervisor must stop the cloud
resource separately. Keep code/data/checkpoints on `/workspace`, synchronize
checkpoints locally, then stop the pod. Stopped pod storage still costs money.

A BC-only cell's `policy_id-bc/best.pt` is also the initialization of its
`policy_id-bc_ppo` cell. BC completion and checkpoint hash are checked before PPO;
PPO cannot silently start from scratch when BC is missing. BC-only has no PPO
stage. PPO-only never opens the expert data. Conventional RNN/GRU cores always
train; they match either the frozen-interface or joint-edge biological capacity.

Teacher data are generated once per task, not once per substrate or seed. Failed
expert qualification remains explicit. No-brain controls use the same data and
20k interface ceiling. Repeated anchored conventional controls share an execution
when their actual configuration is identical.

The report writes test/OOD episode metrics, BC error, PPO AUC and thresholds,
seed variance, and both requested interactions. Common-compute comparisons use
prior measured scores only and show missing coverage instead of extrapolation.
DAgger is documented but deliberately not scheduled in the first pass.
