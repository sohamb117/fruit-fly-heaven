import json

import pytest
from test_compatibility_study import small_study

from connectome_body.compatibility.runner import run_conditions, run_jobs
from connectome_body.compatibility.selection import select_conditions, selection_ids
from connectome_body.compatibility.study import compile_study
from connectome_body.util import atomic_json


def test_selection_is_plan_pinned_budgeted_and_bounds_worker_scope(
    tmp_path, compatibility_manifest_factory
):
    study = small_study(tmp_path, compatibility_manifest_factory)
    root = tmp_path / "plan"
    plan = compile_study(study, root)
    filters = tmp_path / "filters.json"
    atomic_json(
        filters,
        {
            "schema": "compatibility-selection-filter-v1",
            "filters": {
                "kind": ["adapter_only"],
                "family": ["mlp_mlp"],
                "task": ["locomotion"],
                "budget": [1000],
                "training_interactions": [16],
            },
        },
    )
    target = root / "selection.json"
    selected = select_conditions(root / "plan.json", filters, target)
    assert selected["statuses"] == {"ready": 1}
    assert selected["ready_training_interactions"] == 16
    assert selected["ready_evaluation_interactions_upper_bound"] == 48
    result = run_conditions(root / "plan.json", max_runs=1, selection_path=target)
    assert result["results"][0]["condition"] in selected["condition_ids"]
    assert len(result["results"]) == 1
    selected["condition_ids"] = []
    atomic_json(target, selected)
    with pytest.raises(ValueError, match="changed"):
        selection_ids(plan, target)


def test_predictor_inputs_cannot_be_changed_after_plan_compilation(
    tmp_path, compatibility_manifest_factory
):
    study = small_study(tmp_path, compatibility_manifest_factory)
    value = json.loads(study.read_text())
    annotation = tmp_path / "anatomy.json"
    atomic_json(
        annotation,
        {
            "graph_fingerprint": value["graphs"]["fixture"]["fingerprint"],
            "sensory_ids": [],
            "motor_ids": [],
            "provenance": {"source": "test fixture"},
        },
    )
    value["graphs"]["fixture"]["anatomy"] = str(annotation)
    atomic_json(study, value)
    root = tmp_path / "plan"
    plan = compile_study(study, root)
    jobs = [row for row in plan["jobs"] if row["kind"] == "predict_pairs"]
    assert all(str(annotation) in row["input_files"] for row in jobs)
    annotation.write_text("changed after seeing performance\n")
    result = run_jobs(root / "plan.json", max_jobs=1, job_ids=[jobs[0]["id"]])
    assert result["pending"][0]["reason"] == "missing_or_changed_preregistered_input"
