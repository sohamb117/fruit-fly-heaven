# Connectome–body compatibility experiments

The implementation of [the supplied ten-experiment plan](PAPER_PLAN.md) is under
`connectome_body/compatibility/`. Run it with
`uv run --no-sync python -m connectome_body.compatibility` from this directory.
It has a separate CLI and does not replace the original FlyBody imitation or
`adaptation/` campaigns. The original BANC checkpoint remains in
`../../checkpoints/banc-4090-update-008475/latest.pt`.

The suite implements stateless sensory/motor adapters, frozen or permitted-edge
plastic connectomes, parameter-matched RNN/GRU controls, empirically matched RNN
controls, adapter-only controls, all ten tasks, post-training interventions,
transfer, and held-out-pair analysis. A compiled catalog is not a scientific
result or an instruction to run every condition.

## Start here

1. Read [PAPER_PROTOCOL.md](PAPER_PROTOCOL.md) for the fixed estimands,
   normalization, matching rules and model limitations.
2. Read [PAPER_EXPERIMENTS.md](PAPER_EXPERIMENTS.md) for the implementation map.
3. Inspect the current [study configuration](configs/paper/study.json).
4. Prepare inputs and compile an immutable plan; inspect `coverage.json` and
   `prerequisites.json` before launching a bounded worker.

The shared environment already has Python 3.12, PyTorch 2.8.0, MuJoCo 3.13.0 and
the dependencies pinned in `pyproject.toml`/`uv.lock`. Do not synchronize or alter
an environment while an existing campaign is using it. On a fresh checkout,
install `uv`, Python 3.12 and a C++17 compiler, then use `uv sync --frozen` before
starting work. Subsequent commands below use `--no-sync`. The paper's sparse
backend supports CPU and CUDA; it explicitly rejects MPS. CUDA performance
must be measured on the actual target hardware.

The pinned upstream FlyBody source and flight assets use the existing project
preparation commands:

```sh
uv run --no-sync python -m connectome_body.cli bootstrap
uv run --no-sync python -m connectome_body.adaptation.cli assets --download
uv run --no-sync python -m connectome_body.cli prepare banc --download
uv run --no-sync python -m connectome_body.cli prepare malecns --download
```

The flight assets supply the common wing-pattern generator. The native paper
controller does not need teacher actions: it uses recurrent PPO across all bodies.

## Biological and physical inputs

Prepared local graph directories are:

| Graph | Directory | Neurons | Directed edges |
|---|---|---:|---:|
| BANC v888 | `data/graphs/banc` | 175,401 | 13,542,180 |
| MaleCNS | `data/graphs/malecns` | 165,122 | 25,563,096 |
| Cook 2019 chemical hermaphrodite | `data/graphs/celegans-cook2019-chemical` | 302 | 3,671 |
| Fish1 | `data/graphs/fish1` | Requires authenticated export | Requires export |

Graph fingerprints and release membership are in `configs/paper/study.json` and
each graph's manifest. Cook edge weights are EM serial-section extent, not
synapse counts. The default magnitude transform is therefore a common numerical
rule, not a claim that the source weights have equivalent physical units.

Prepare the two additional bodies and their mechanical checks:

```sh
uv run --no-sync python -m connectome_body.compatibility prepare-worm-body
uv run --no-sync python -m connectome_body.compatibility prepare-fish-body
uv run --no-sync python -m connectome_body.compatibility qualify-body --body worm --manifest data/paper-bodies/worm/manifest.json --output data/paper-bodies/worm/qualification-v1.json
uv run --no-sync python -m connectome_body.compatibility qualify-body --body fish --manifest data/paper-bodies/fish/manifest.json --output data/paper-bodies/fish/qualification-v1.json
```

The worm executes the pinned published 50-segment mechanical solver with 48 muscle
commands; its original neural circuit is excluded. The fish is an explicitly
documented 3D extension of simZFish's collision morphology, masses and inertias.
It uses MuJoCo hydrodynamics, hydrostatic buoyancy and four added pectoral-fin
degrees of freedom. It is **not numerically equivalent to published simZFish or
an empirically validated zebrafish digital twin**. Its source, assumptions and
one small inertia feasibility correction are retained in its manifest.

The mechanical qualification checks actual actuator-driven propulsion in both
directions, steering, loss of propulsion after actuator failure, worm posture
tracking and fish vertical actuation. It is separate from learned-policy
evaluation. The planner requires a current passing qualification for these
native bodies. A changed body implementation requires a new qualification path
and a new plan; keep old evidence intact.

Prepare Cook data on a new machine:

```sh
uv run --no-sync python -m connectome_body.compatibility prepare-celegans
```

Prepare structural communities once per graph. For example:

```sh
uv run --no-sync python -m connectome_body.compatibility communities --graph data/graphs/banc --output data/paper-annotations/banc/communities.json
```

`prepare-anatomy` reads release-pinned BANC/MaleCNS annotation feathers or the
Cook importer's `cell-types.json`. These privileged annotations are used only
for anatomical oracles, anatomical descriptors and declared subgraph hypotheses.
They are never fed into a generic adapter. Example:

```sh
uv run --no-sync python -m connectome_body.compatibility prepare-anatomy --kind celegans --graph data/graphs/celegans-cook2019-chemical --annotations data/graphs/celegans-cook2019-chemical/cell-types.json --output data/paper-annotations/celegans --subgraphs-output data/paper-subgraphs/celegans
```

The current BANC, MaleCNS and Cook preparations include anatomical ports and ten
task-associated module selections each. Cross-species task assignments are
preregistered functional hypotheses, not neuron homologies or established task
specificity. Inspect each selection's provenance before interpreting Experiment 7.

## Fish1 access

Follow the [official Fish1 programmatic access instructions](https://fish1-release.storage.googleapis.com/programmatic.html)
and configure CAVE authentication locally. Do not put a token in a run
configuration, command-line argument, repository or report. Choose and record
an exact materialization version, membership rule and reconstruction coverage.
The documentation's example version is not automatically the study version.

```sh
uv run --no-sync --with caveclient==8.2.1 python -m connectome_body.compatibility export-fish1 --version MATERIALIZATION_INTEGER --coverage 'Describe the selected reconstruction and proofreading coverage' --membership single_soma_roots --output data/raw/fish1-versioned-export
uv run --no-sync python -m connectome_body.compatibility import-fish1 --export data/raw/fish1-versioned-export --output data/graphs/fish1
```

The exporter verifies the live segmentation endpoint, uses the fixed
materialization, preserves uint64 root IDs losslessly, checks page counts and
duplicate IDs, and resumes from checksummed pages. The importer excludes zero
and multiple-soma roots, preserves disconnected selected neurons and reports
annotation coverage. It never remaps roots to a newer segmentation.

After import, pin the resulting graph fingerprint in a new study configuration.
Prepare communities and provenance-backed anatomical/functional selections where
annotations support them. The generic interface needs none of these labels.
Missing Fish1 oracle or task-module inputs remain explicit prerequisites; the
suite does not invent sensory/motor identities from excitatory/inhibitory labels.

## Plan, benchmark, then run a bounded subset

```sh
uv run --no-sync python -m connectome_body.compatibility plan --study configs/paper/study.json --output runs/paper-plan-v1
uv run --no-sync python -m connectome_body.compatibility status --plan runs/paper-plan-v1/plan.json
```

The plan includes all ten experiments, exact parameter counts, input checksums,
body dimensions, immutable run configurations, shared-baseline references and
post-training dependencies. Unsupported capacities are recorded as infeasible,
not padded with unused parameters. Missing inputs block their conditions rather
than silently selecting smaller or synthetic substitutes.

The full catalog currently has about 24,000 distinct training configurations.
The default million-interaction learning budget and repeated evaluations make
this a catalog to stage, not a lean compute allocation. Start with BANC hover:
real / degree-rewired / N-and-M-matched random / adapter only, capacities 5k and
80k, three paired seeds. Run one short smoke and a hardware benchmark before
the 24 scientific runs. Use the selection file supplied under `configs/paper/`
to choose those conditions; review actual counts and budgets before execution.

```sh
uv run --no-sync python -m connectome_body.compatibility select --plan runs/paper-plan-v1/plan.json --filters configs/paper/banc_hover_mvp.json --output runs/paper-plan-v1/banc-hover-mvp.json
```

The selection includes both training interactions and an upper bound on all
development/test interactions. To execute at most one selected condition for a
bounded interval on the current machine:

```sh
uv run --no-sync python -m connectome_body.compatibility worker --plan runs/paper-plan-v1/plan.json --selection runs/paper-plan-v1/banc-hover-mvp.json --max-runs 1 --max-seconds 1800
```

For a ready condition ID from the plan:

```sh
uv run --no-sync python -m connectome_body.compatibility benchmark --plan runs/paper-plan-v1/plan.json --condition CONDITION_ID --output data/paper-calibration/benchmark.json --batches 1 4 16 --lengths 8 16 --repeats 5 --warmup 2
uv run --no-sync python -m connectome_body.compatibility worker --plan runs/paper-plan-v1/plan.json --condition CONDITION_ID --max-runs 1 --max-seconds 1800
```

Workers run only on the current machine or an already allocated machine. No
command rents, starts or stops a pod. `--max-seconds` pauses at a saved rollout
boundary; allow for one rollout, optimization and scheduled evaluation beyond
that time. It is not a provider billing cutoff. Repeating the worker command
resumes its atomic checkpoint using the same plan and environment.

The benchmark measures sparse forward transitions, TBPTT/Adam, peak CUDA memory,
batch and sequence scaling, and a common critic. Its regression objective is a
compute surrogate; it is not an embodied-learning result. It excludes physics,
so end-to-end throughput must also be measured from training logs.

To prepare the compute-matched RNN control on the target GPU:

```sh
uv run --no-sync python -m connectome_body.compatibility compute-match --plan runs/paper-plan-v1/plan.json --condition CONDITION_ID --hidden-sizes 32 64 128 256 512 1024 --output data/paper-calibration/compute-matches.json
```

Only a measured width within the declared tolerance and timing stability is
accepted. A miss remains `no_match`; expand the preregistered width search without
looking at rewards. Recompile to a new plan after adding calibrations. Results
from a different device, precision, batch, sequence length or source revision
are not accepted as compute matches.

## Results and checkpoint safety

Each training directory contains `manifest.json`, `latest.pt`, `best.pt`,
`learning_curve.json`, update logs and a terminal result or explicit failure
record. A checkpoint retains actor, critic, optimizer, neural/physical state,
RNGs, scenario counters and evaluation selection state. Source data and body
assets remain external, checksummed dependencies. Copy the run directory and
its referenced inputs before discarding an allocated machine.

`best.pt` is selected using development episodes only. Post-training jobs use
that exact policy, common held-out episode seeds and no further learning except
explicitly labeled fine-tuning. Run bounded jobs, then generate the report:

```sh
uv run --no-sync python -m connectome_body.compatibility jobs --plan runs/paper-plan-v1/plan.json --max-jobs 8 --experiment 8
uv run --no-sync python -m connectome_body.compatibility report --plan runs/paper-plan-v1/plan.json --output reports/paper-v1
```

Unfinished conditions, missing controls, numerical failures and unidentifiable
effects remain visible. An I/O or device failure is not counted as evidence
against a connectome. Native-body software tests and short sparse benchmarks
establish implementation behavior, not any of the paper's proposed advantages.

## Validation

```sh
uv run --no-sync ruff check connectome_body/compatibility tests/test_compatibility_*.py
uv run --no-sync pytest -q tests/test_compatibility_*.py
```

Native tests require the pinned local bodies and FlyBody assets. Skips must be
reported; a fixture-only test pass does not certify a missing native backend.
Use the saved validation report for the exact environment, checks and remaining
execution prerequisites.
