"""Versioned, resumable Fish1 table export and lossless neuron-root graph ingestion.

The client is injected. Authentication remains in CAVE's local credential store;
neither tokens nor client/session objects are serialized by this module.
"""

from __future__ import annotations

import csv
import json
import os
import sqlite3
import tempfile
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from numbers import Integral
from pathlib import Path
from urllib.parse import unquote, urlsplit, urlunsplit

import numpy as np

from ..graphs import save_graph
from ..util import atomic_json, digest_file, digest_json
from .datasets import validate_fish1_provenance


def integer_id(value):
    if isinstance(value, bool) or not isinstance(value, (str, Integral)):
        raise ValueError("Neuron and synapse IDs must never pass through floating point")
    if isinstance(value, str) and (not value.isdecimal() or not value.isascii()):
        raise ValueError("IDs must be unsigned decimal integers")
    result = int(value)
    if not 0 <= result < 2**64:
        raise ValueError("ID outside uint64 range")
    return str(result)


@dataclass(frozen=True)
class Fish1ExportSpec:
    materialization_version: int
    proofreading_coverage: str
    membership_mode: str = "single_soma_roots"
    datastack: str = "fish1_full"
    segmentation_table: str = "fish1_v250915"
    soma_table: str = "somas"
    synapse_table: str = "synapses_axde_label"
    page_size: int = 50_000
    server_url: str = "https://global.brain-wire-test.org/"

    def validate(self):
        if type(self.materialization_version) is not int or self.materialization_version < 1:
            raise ValueError("Specify a fixed materialization integer, never latest")
        if not self.proofreading_coverage.strip():
            raise ValueError(
                "Describe reconstruction coverage; a soma-root graph is not a fully proofread connectome"
            )
        if self.membership_mode not in (
            "single_soma_roots",
            "molecularly_annotated_single_soma_roots",
        ):
            raise ValueError("Declare a supported membership rule before downloading")
        if type(self.page_size) is not int or not 1 <= self.page_size <= 100_000:
            raise ValueError("Page size must be between 1 and 100000")
        if (
            self.datastack != "fish1_full"
            or self.server_url != "https://global.brain-wire-test.org/"
        ):
            raise ValueError("This exporter is restricted to the documented Fish1 service")
        if any(
            not value for value in (self.segmentation_table, self.soma_table, self.synapse_table)
        ):
            raise ValueError("Declare segmentation and annotation tables")


def _count(value):
    if hasattr(value, "to_dict"):
        value = value.to_dict("records")
    if isinstance(value, list) and len(value) == 1:
        value = value[0]
    if isinstance(value, dict) and len(value) == 1:
        value = next(iter(value.values()))
    if not isinstance(value, Integral) or isinstance(value, bool) or value < 0:
        raise ValueError("CAVE count response must contain one nonnegative integer")
    return int(value)


def _jsonable(value):
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, np.generic):
        return value.item()
    return value


def _write_page(path, rows, columns):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".page-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="raise")
            writer.writeheader()
            writer.writerows(rows)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def export_fish1(client, spec: Fish1ExportSpec, output):
    spec.validate()
    output = Path(output).resolve()
    request = {"schema": "fish1-export-request-v1", "spec": asdict(spec)}
    request_id = digest_json(request)
    if (output / "provenance.json").exists():
        saved = json.loads((output / "provenance.json").read_text())
        if saved.get("request_identity") != request_id:
            raise FileExistsError("Completed export uses another fixed version or membership rule")
        for name, item in saved["files"].items():
            if digest_file(output / name) != item["sha256"]:
                raise ValueError("A completed Fish1 export page changed")
        return saved
    checkpoint = output / "export-progress.json"
    progress = {"request_identity": request_id, "files": {}, "tables": {}}
    if checkpoint.exists():
        progress = json.loads(checkpoint.read_text())
        if progress.get("request_identity") != request_id:
            raise ValueError("Resume requires exactly the original Fish1 export specification")
    output.mkdir(parents=True, exist_ok=True)
    atomic_json(output / "request.json", request)
    source = client.info.segmentation_source(datastack_name=spec.datastack, use_stored=False)
    parsed = urlsplit(source.removeprefix("graphene://"))
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or unquote(parsed.path.rstrip("/").split("/")[-1]) != spec.segmentation_table
    ):
        raise ValueError("Live CAVE segmentation source differs from the declared Fish1 table")
    # Store only the public endpoint. Credentials, query parameters and URL
    # fragments can never enter data provenance or an export checkpoint.
    public_source = urlunsplit((parsed.scheme, parsed.hostname, parsed.path, "", ""))
    if progress.get("segmentation_source", public_source) != public_source:
        raise ValueError("Fish1 segmentation endpoint changed since the export began")
    progress["segmentation_source"] = public_source
    materialize = client.materialize
    metadata = _jsonable(
        materialize.get_version_metadata(
            version=spec.materialization_version, datastack_name=spec.datastack
        )
    )
    if int(metadata.get("version", spec.materialization_version)) != spec.materialization_version:
        raise ValueError("CAVE returned metadata for a different materialization")
    tables = materialize.get_tables(
        version=spec.materialization_version, datastack_name=spec.datastack
    )
    if not {spec.soma_table, spec.synapse_table} <= set(tables):
        raise ValueError("Required soma/synapse tables are absent from the pinned materialization")
    columns = {
        spec.soma_table: ["id", "pt_root_id", "cell_type"],
        spec.synapse_table: ["id", "pre_pt_root_id", "post_pt_root_id", "tag"],
    }
    # A disk-backed unique index detects overlapping or reordered pages without
    # retaining tens of millions of synapse IDs in a Python set.
    with tempfile.TemporaryDirectory(prefix="fish1-id-audit-", dir=output) as audit_dir:
        connection = sqlite3.connect(str(Path(audit_dir) / "ids.sqlite"))
        try:
            connection.execute(
                "CREATE TABLE seen (table_name TEXT, row_id TEXT, PRIMARY KEY(table_name, row_id)) WITHOUT ROWID"
            )
            for table, fields in columns.items():
                query = {
                    "materialization_version": spec.materialization_version,
                    "datastack_name": spec.datastack,
                    "return_df": False,
                    "select_columns": fields,
                    "merge_reference": True,
                }
                expected = _count(materialize.query_table(table, **query, get_counts=True))
                if (
                    table in progress["tables"]
                    and progress["tables"][table]["expected_rows"] != expected
                ):
                    raise ValueError("Row count changed at a supposedly fixed materialization")
                progress["tables"][table] = {"expected_rows": expected}
                offset = 0
                while offset < expected:
                    relative = f"{table}/page-{offset:012d}.csv"
                    path = output / relative
                    if relative in progress["files"]:
                        item = progress["files"][relative]
                        if digest_file(path) != item["sha256"]:
                            raise ValueError("Cached Fish1 page checksum mismatch")
                        with path.open(newline="") as stream:
                            rows = list(csv.DictReader(stream))
                        if len(rows) != item["rows"]:
                            raise ValueError("Cached Fish1 page row count mismatch")
                    else:
                        rows = materialize.query_table(
                            table,
                            **query,
                            offset=offset,
                            limit=min(spec.page_size, expected - offset),
                        )
                        if hasattr(rows, "to_dict"):
                            rows = rows.to_dict("records")
                        if not isinstance(rows, list) or not rows:
                            raise ValueError("CAVE pagination ended before its declared count")
                        canonical = []
                        for row in rows:
                            if not set(fields) <= row.keys():
                                raise ValueError("Unexpected Fish1 table columns")
                            values = {
                                key: integer_id(row[key])
                                if key == "id" or key.endswith("root_id")
                                else str(row[key])
                                if row[key] is not None
                                else "na"
                                for key in fields
                            }
                            canonical.append(values)
                        rows = canonical
                        _write_page(path, rows, fields)
                    if offset + len(rows) > expected:
                        raise ValueError("CAVE returned more annotations than its declared count")
                    try:
                        connection.executemany(
                            "INSERT INTO seen VALUES (?, ?)", [(table, row["id"]) for row in rows]
                        )
                        connection.commit()
                    except sqlite3.IntegrityError as exc:
                        raise ValueError(
                            "Duplicate Fish1 row ID: unstable pagination or overlapping table rows"
                        ) from exc
                    progress["files"][relative] = {
                        "sha256": digest_file(path),
                        "rows": len(rows),
                        "table": table,
                        "offset": offset,
                    }
                    offset += len(rows)  # Respect server-side caps smaller than the request.
                    progress["tables"][table]["exported_rows"] = offset
                    atomic_json(checkpoint, progress)
                if _count(materialize.query_table(table, **query, get_counts=True)) != expected:
                    raise ValueError("Fish1 count changed during a fixed-version export")
        finally:
            connection.close()
    membership = "one nonzero segmentation root with exactly one soma annotation; preserve disconnected selected roots"
    if spec.membership_mode.startswith("molecularly"):
        membership += "; restrict to soma cell_type exc or inh"
    provenance = {
        "schema": "fish1-versioned-export-v1",
        "request_identity": request_id,
        "datastack": spec.datastack,
        "materialization_version": spec.materialization_version,
        "segmentation_table": spec.segmentation_table,
        "segmentation_source": public_source,
        "soma_table": spec.soma_table,
        "synapse_table": spec.synapse_table,
        "membership_rule": membership,
        "membership_mode": spec.membership_mode,
        "proofreading_coverage": spec.proofreading_coverage,
        "exported_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": progress["files"],
        "tables": progress["tables"],
        "materialization_metadata": metadata,
        "documentation": "https://fish1-release.storage.googleapis.com/programmatic.html",
        "is_synthetic": False,
        "current_root_remapping": False,
    }
    validate_fish1_provenance(provenance)
    atomic_json(output / "provenance.json", provenance)
    return provenance


def import_fish1(export_directory, output):
    directory, output = Path(export_directory).resolve(), Path(output)
    provenance = validate_fish1_provenance(json.loads((directory / "provenance.json").read_text()))
    if (
        provenance.get("schema") != "fish1-versioned-export-v1"
        or provenance.get("current_root_remapping") is not False
    ):
        raise ValueError("Only the fixed-version Fish1 export schema is accepted")
    if output.exists():
        raise FileExistsError("Prepared Fish1 graphs are immutable")
    files = provenance["files"]
    for name, item in files.items():
        path = (directory / name).resolve()
        if not path.is_relative_to(directory) or digest_file(path) != item["sha256"]:
            raise ValueError("Fish1 page is outside the export or has changed")

    def table_rows(table):
        items = sorted(
            ((name, item) for name, item in files.items() if item["table"] == table),
            key=lambda pair: pair[1]["offset"],
        )
        offset = 0
        for name, item in items:
            if item["offset"] != offset:
                raise ValueError("Missing or overlapping Fish1 page interval")
            with (directory / name).open(newline="") as stream:
                rows = list(csv.DictReader(stream))
            if len(rows) != item["rows"]:
                raise ValueError("Fish1 page row count mismatch")
            yield from rows
            offset += len(rows)
        if offset != provenance["tables"][table]["expected_rows"]:
            raise ValueError("Fish1 export is incomplete")

    roots, soma_ids = defaultdict(list), set()
    for row in table_rows(provenance["soma_table"]):
        soma, root = integer_id(row["id"]), integer_id(row["pt_root_id"])
        if soma in soma_ids:
            raise ValueError("Duplicate soma annotation in Fish1 export")
        soma_ids.add(soma)
        roots[root].append((soma, row["cell_type"]))
    mode = provenance["membership_mode"]
    if mode not in ("single_soma_roots", "molecularly_annotated_single_soma_roots"):
        raise ValueError("Unknown Fish1 membership mode")
    nodes = sorted(
        (
            root
            for root, rows in roots.items()
            if root != "0"
            and len(rows) == 1
            and (mode == "single_soma_roots" or rows[0][1] in ("exc", "inh"))
        ),
        key=int,
    )
    if len(nodes) < 4:
        raise ValueError("The declared Fish1 membership yields fewer than four neurons")
    lookup = {node: i for i, node in enumerate(nodes)}
    signs = np.array(
        [{"exc": 1, "inh": -1}.get(roots[node][0][1], 0) for node in nodes], dtype=np.int8
    )
    counts = Counter()
    with tempfile.TemporaryDirectory(prefix="fish1-aggregate-", dir=directory) as aggregate_dir:
        connection = sqlite3.connect(str(Path(aggregate_dir) / "edges.sqlite"))
        try:
            connection.execute("CREATE TABLE seen (synapse TEXT PRIMARY KEY) WITHOUT ROWID")
            connection.execute(
                "CREATE TABLE edges (src INTEGER, dst INTEGER, n INTEGER, PRIMARY KEY(src, dst)) WITHOUT ROWID"
            )
            batch = []
            for row in table_rows(provenance["synapse_table"]):
                synapse = integer_id(row["id"])
                try:
                    connection.execute("INSERT INTO seen VALUES (?)", (synapse,))
                except sqlite3.IntegrityError as exc:
                    raise ValueError("Duplicate synapse annotation in Fish1 export") from exc
                src, dst = integer_id(row["pre_pt_root_id"]), integer_id(row["post_pt_root_id"])
                counts["raw_synapses"] += 1
                if src not in lookup or dst not in lookup:
                    counts["outside_membership"] += 1
                    continue
                if src == dst:
                    counts["autapses_excluded"] += 1
                    continue
                source, target = lookup[src], lookup[dst]
                batch.append((source, target, 1))
                counts["retained_synapses"] += 1
                tag_sign = {"1": -1, "2": 1}.get(row["tag"], 0)
                if tag_sign and signs[source] and tag_sign != signs[source]:
                    counts["edge_tag_disagrees_with_soma_label"] += 1
                if len(batch) >= 100_000:
                    connection.executemany(
                        "INSERT INTO edges VALUES (?, ?, ?) ON CONFLICT(src, dst) DO UPDATE SET n=n+1",
                        batch,
                    )
                    connection.commit()
                    batch.clear()
            if batch:
                connection.executemany(
                    "INSERT INTO edges VALUES (?, ?, ?) ON CONFLICT(src, dst) DO UPDATE SET n=n+1",
                    batch,
                )
            connection.commit()
            size = connection.execute("SELECT COUNT(*) FROM edges").fetchone()[0]
            src, dst, weight = (
                np.empty(size, np.uint32),
                np.empty(size, np.uint32),
                np.empty(size, np.float32),
            )
            cursor = connection.execute("SELECT src, dst, n FROM edges ORDER BY dst, src")
            offset = 0
            while chunk := cursor.fetchmany(100_000):
                values = np.asarray(chunk, dtype=np.int64)
                if values[:, 2].max() > 2**24:
                    raise ValueError("Synapse count exceeds exact float32 integer representation")
                end = offset + len(values)
                src[offset:end], dst[offset:end], weight[offset:end] = values.T
                offset = end
        finally:
            connection.close()
    return save_graph(
        output,
        nodes,
        src,
        dst,
        weight,
        signs=signs,
        provenance={
            "dataset": "Fish1",
            "species": "Danio rerio",
            "developmental_stage": "7 dpf",
            "resolution": "versioned single-soma segmentation root, not guaranteed fully proofread neuron",
            "weight_semantics": "count of retained unique axon-to-dendrite synapse annotation IDs",
            "sign_evidence": "soma molecular cell_type exc/inh; unknown remains zero; edge tags do not override soma identity",
            "export": provenance,
            "export_provenance_sha256": digest_file(directory / "provenance.json"),
            "membership_audit": {
                "selected_roots": len(nodes),
                "multiple_soma_roots_excluded": sum(len(rows) > 1 for rows in roots.values()),
                "zero_root_somas_excluded": len(roots.get("0", [])),
                **counts,
            },
            "citation": "https://fish1-release.storage.googleapis.com/paper.html",
            "is_synthetic": provenance.get("is_synthetic", False),
        },
    )
