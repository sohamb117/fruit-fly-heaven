import copy
import json
from types import SimpleNamespace

import numpy as np
import pytest

from connectome_body.compatibility.fish1 import (
    Fish1ExportSpec,
    export_fish1,
    import_fish1,
    integer_id,
)


class Tables:
    def __init__(self):
        self.roots = [2**63 + value for value in (5, 7, 11, 13, 17, 19)]
        labels = ("exc", "inh", "na", "exc", "na", "na", "na", "na")
        roots = [*self.roots[:5], 0, self.roots[5], self.roots[5]]
        self.data = {
            "somas": [
                {"id": i + 1, "pt_root_id": root, "cell_type": label}
                for i, (root, label) in enumerate(zip(roots, labels, strict=True))
            ]
        }
        self.data["synapses_axde_label"] = [
            {
                "id": i + 1,
                "pre_pt_root_id": self.roots[s],
                "post_pt_root_id": self.roots[d],
                "tag": tag,
            }
            for i, (s, d, tag) in enumerate(
                [
                    (0, 1, "2"),
                    (0, 1, "1"),
                    (1, 2, "1"),
                    (2, 0, "na"),
                    (0, 0, "2"),
                    (3, 5, "2"),
                    (5, 0, "na"),
                    (3, 0, "2"),
                ]
            )
        ]
        self.calls, self.fail = [], False

    def get_version_metadata(self, **kwargs):
        assert kwargs == {"version": 574, "datastack_name": "fish1_full"}
        return {"version": 574, "time_stamp": "2025-09-15T00:00:00Z"}

    def get_tables(self, **kwargs):
        assert kwargs == {"version": 574, "datastack_name": "fish1_full"}
        return list(self.data)

    def query_table(self, table, **kwargs):
        assert kwargs["materialization_version"] == 574
        assert kwargs["return_df"] is False
        self.calls.append((table, copy.deepcopy(kwargs)))
        if kwargs.get("get_counts"):
            return [{"count": len(self.data[table])}]
        if self.fail and table == "synapses_axde_label" and kwargs["offset"] == 2:
            raise ConnectionError("simulated interruption")
        start = kwargs["offset"]
        return self.data[table][start : start + min(2, kwargs["limit"])]


def client_for(tables, source="graphene://https://example.test/segmentation/table/fish1_v250915"):
    def segmentation_source(**kwargs):
        assert kwargs == {"datastack_name": "fish1_full", "use_stored": False}
        return source

    return SimpleNamespace(
        materialize=tables, info=SimpleNamespace(segmentation_source=segmentation_source)
    )


def test_export_resume_and_import_preserve_large_ids_counts_signs_and_isolates(tmp_path):
    tables = Tables()
    client = client_for(tables)
    spec = Fish1ExportSpec(574, "Synthetic source for software testing", page_size=3)
    tables.fail = True
    with pytest.raises(ConnectionError):
        export_fish1(client, spec, tmp_path / "export")
    progress = json.loads((tmp_path / "export/export-progress.json").read_text())
    assert progress["tables"]["synapses_axde_label"]["exported_rows"] == 2
    tables.fail = False
    tables.calls.clear()
    provenance = export_fish1(client, spec, tmp_path / "export")
    assert not any(
        table == "somas" and not options.get("get_counts") for table, options in tables.calls
    )
    assert provenance["current_root_remapping"] is False
    graph = import_fish1(tmp_path / "export", tmp_path / "graph")
    assert graph.n == 5 and graph.m == 4
    assert set(graph.node_ids) == set(map(str, tables.roots[:5]))
    np.testing.assert_array_equal(graph.signs, [1, -1, 0, 1, 0])
    assert graph.weight.sum() == 5
    assert graph.manifest["summary"]["isolated_neurons"] == 1
    audit = graph.manifest["provenance"]["membership_audit"]
    assert audit["multiple_soma_roots_excluded"] == 1 and audit["autapses_excluded"] == 1
    assert audit["edge_tag_disagrees_with_soma_label"] == 1
    page = next((tmp_path / "export/somas").glob("*.csv"))
    page.write_text(page.read_text() + "bad\n")
    with pytest.raises(ValueError, match="changed"):
        import_fish1(tmp_path / "export", tmp_path / "bad")


def test_duplicate_synapses_and_float_ids_cannot_become_connectivity(tmp_path):
    tables = Tables()
    tables.data["synapses_axde_label"][2]["id"] = tables.data["synapses_axde_label"][0]["id"]
    with pytest.raises(ValueError, match="Duplicate Fish1"):
        export_fish1(
            client_for(tables),
            Fish1ExportSpec(574, "fixture"),
            tmp_path / "duplicate",
        )
    for value in (float(2**63 + 5), True, "1.0", "-1", str(2**64)):
        with pytest.raises(ValueError):
            integer_id(value)
    with pytest.raises(ValueError, match="fixed materialization"):
        Fish1ExportSpec("latest", "unknown").validate()


def test_export_checks_the_actual_segmentation_endpoint_and_does_not_store_url_credentials(
    tmp_path,
):
    tables = Tables()
    with pytest.raises(ValueError, match="segmentation source"):
        export_fish1(
            client_for(tables, "graphene://https://example.test/table/other_release"),
            Fish1ExportSpec(574, "fixture"),
            tmp_path / "wrong",
        )
    assert not tables.calls
    result = export_fish1(
        client_for(
            tables,
            "graphene://https://user:private@example.test/table/fish1_v250915?token=private#private",
        ),
        Fish1ExportSpec(574, "fixture"),
        tmp_path / "correct",
    )
    assert result["segmentation_source"] == "https://example.test/table/fish1_v250915"
    assert "private" not in json.dumps(result)
